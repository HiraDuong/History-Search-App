package controller;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.VBox;
import screen.MainScreen;
import javafx.scene.control.TextField;
import javafx.scene.control.ToolBar;
public class ContentLayerController {
	@FXML
	public TextField tf_searchBarSmall;
	@FXML
	public VBox vb_contentWrapper;
}
