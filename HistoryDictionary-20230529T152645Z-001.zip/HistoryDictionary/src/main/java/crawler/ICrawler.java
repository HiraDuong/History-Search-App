package crawler;

import java.util.List;

import model.Model;

public interface ICrawler {
	List<Model> crawl();
}
